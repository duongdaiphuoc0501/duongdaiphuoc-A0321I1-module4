package com.codegym.springsecuritya03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityA03Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringsecurityA03Application.class, args);
    }

}
