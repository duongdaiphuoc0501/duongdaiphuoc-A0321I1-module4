package com.codegym.springsecuritya03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecurityA03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
