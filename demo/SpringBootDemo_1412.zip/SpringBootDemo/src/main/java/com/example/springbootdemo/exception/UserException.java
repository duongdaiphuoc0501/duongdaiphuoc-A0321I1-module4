package com.example.springbootdemo.exception;

public class UserException extends Exception {
    public UserException(){};
    public UserException(String s) {
        super(s);
    }
}
