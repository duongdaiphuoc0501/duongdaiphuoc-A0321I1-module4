package com.codegym.springsecuritya03.repository;

import com.codegym.springsecuritya03.entity.User;
import com.codegym.springsecuritya03.entity.UserRole;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserRoleRepository extends CrudRepository<UserRole, Long> {
    List<UserRole> findAllByUser(User user);

    @Query("select ur.role.roleName from UserRole ur where ur.user.userId = :userId")
    List<String> findAllRoleByUser(Long userId);
}
